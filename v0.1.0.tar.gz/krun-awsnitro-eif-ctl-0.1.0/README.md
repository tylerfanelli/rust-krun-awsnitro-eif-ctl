# krun-awsnitro-eif-ctl

Tool to configure cached EIF files for the krun-awsnitro runtime for AWS Nitro Enclaves
